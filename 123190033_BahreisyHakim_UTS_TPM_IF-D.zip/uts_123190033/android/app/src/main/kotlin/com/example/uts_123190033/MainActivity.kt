package com.example.uts_123190033

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
